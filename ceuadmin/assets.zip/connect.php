<?php
$con = mysqli_connect("localhost","ceuservice","@{+A_gh8RIkQ", "ceuservicesD");
// $con = mysqli_connect("localhost","root","", "ceu");
session_start();
date_default_timezone_set("America/New_York");
$title="CEUTrainers";
?>